from .extract_placeholders import extract_placeholders

__all__ = [
    "extract_placeholders"
]