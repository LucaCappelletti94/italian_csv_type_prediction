"""Current version of package italian_csv_type_prediction"""
__version__ = "1.1.41"