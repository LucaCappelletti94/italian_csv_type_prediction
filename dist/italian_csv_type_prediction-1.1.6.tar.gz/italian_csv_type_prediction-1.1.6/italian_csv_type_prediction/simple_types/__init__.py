from .any_simple_type import AnySimpleTypePredictor

__all__ = ["AnySimpleTypePredictor"]