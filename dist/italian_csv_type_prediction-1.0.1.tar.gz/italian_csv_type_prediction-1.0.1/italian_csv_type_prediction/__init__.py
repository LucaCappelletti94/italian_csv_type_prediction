from .models import predict_types

__all__ = ["predict_types"]