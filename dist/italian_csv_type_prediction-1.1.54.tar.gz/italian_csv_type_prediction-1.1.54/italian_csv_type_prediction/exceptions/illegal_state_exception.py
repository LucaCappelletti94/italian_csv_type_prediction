class IllegalStateError(RuntimeError):
    pass