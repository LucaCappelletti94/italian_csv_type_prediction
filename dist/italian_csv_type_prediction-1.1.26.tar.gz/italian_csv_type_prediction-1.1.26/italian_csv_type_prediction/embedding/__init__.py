from .dataframe_embedding import DataframeEmbedding

__all__ = [
    "DataframeEmbedding"
]