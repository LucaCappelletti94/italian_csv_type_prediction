from .type_predictor import TypePredictor

__all__ = ["TypePredictor"]